<?php

namespace Models;

class CMS extends Model
{
    protected $fillable = ['key', 'value'];
}
