<?php

namespace Models;

class Contact extends Model
{
    protected $fillable = ['name', 'email', 'message'];
}
