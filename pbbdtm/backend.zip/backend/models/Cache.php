<?php

namespace Models;

class Cache extends Model
{
    protected $fillable = ['key', 'value'];
}
