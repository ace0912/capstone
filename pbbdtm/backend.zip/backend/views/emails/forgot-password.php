<a href="$url">
    Reset Password
</a>