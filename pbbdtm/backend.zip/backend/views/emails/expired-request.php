<div>
    <p>Hi $name,</p>
    <p>We want to inform you that your request (ID: $requestID) submitted at $date has expired.</p>
    <p>Document Type: $documentType</p>
    <p>Last Status: $lastStatus</p>
</div>