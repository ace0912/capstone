<div>
    <div>
        <h3>Greetings $name!</h3>
    </div>
    <div>
        <div>
            <p>Your request (ID: $requestID) has been submitted successfully.</p>
            <p>We will notify you when your request gets an update.</p>
            <p>Document Requested: $documentType</p>
            <p>Date Submitted: $date</p>
        </div>
    </div>
</div>