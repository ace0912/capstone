<div>
    <p>Hi $name!</p>
    <p>Your request (ID: $requestID) is updated to: <b>$status</b></p>
    <p>Last Updater: $updater</p>
    <p>Date Updated: $date</p>
</div>